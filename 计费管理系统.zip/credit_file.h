#pragma once
#include"model.h"
int savecredittofile(const credit* pcredit, const char* path);
int readcredit(const char* path);
int readcreditfile();
int changecreditdate(const char* path);