#ifndef card_service_h
#define card_service_h
#include"model.h"
void releasecardlist();
int addcardtolist(card card);
card* checkcard(const char* name, const char* pwd,int *index);
card* refercard(const char* name, int* index);
card* showallcard();
card* countdate(float* totaluse, float* earn);
#endif