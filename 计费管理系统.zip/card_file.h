#pragma once
#include"model.h"
int savecard(const card* pcard, const char* path);
int readcard(const char* path);
int isExsit(char* num, const char* path);
int updatecard(const card* pcard, const char* pPath, int nIndex);

