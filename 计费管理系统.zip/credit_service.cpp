#include<stdio.h>
#include<string.h>
#include"model.h"
#include"global.h"
#include<time.h>
#include"tool.h"
#include<stdlib.h>
#include"credit_file.h"
#include"credit_service.h"
#include"service.h"
ipcreditnode head = NULL, current = NULL, prev = NULL;
credit* querycredit(const char* name, int* index)//��ѯ�����ļ���Ϣ
{
	current = head;
	ipcreditnode current1 = NULL;
	if (current != NULL)
	{
		current1 = current;
		while (current1 != NULL)
		{
			if (strcmp(current1->date.cardname, name) == 0)
			{
				return &current1->date;
			}
			(*index)++;
			current1 = current1->next;
		}
	}
	return NULL;
}
int addcredittolist(credit bill)
{

	current = (ipcreditnode)malloc(sizeof(creditnode));
	if (head == NULL)head = current;
	else prev->next = current;
	current->next = NULL;
	current->date = bill;
	prev = current;
	return TRUE;
}
void releasecreditlist()//�ͷ��ڴ棬��ֹ�ڴ�й¶
{
	current = head;
	while (current != NULL)
	{
		head = current->next;
		free(current);
		current = head;
	}
	current = NULL;
	head = NULL;
}
