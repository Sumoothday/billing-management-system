#pragma once
int savebillingtofile(const billing* pbilling, const char* path);
int readbilling( const char* path);
int updatebill(const billing* pbill, const char* pPath, int nIndex);
int readfile(char *name);
