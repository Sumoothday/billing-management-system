#ifndef menu_h
#define menu_h
void print();
void outputmenu();
void logon();
void settle();
void addmoney();
void refundmoney();
void cancel();
void count();
void docredit();
#endif 
 