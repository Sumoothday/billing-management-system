#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<string.h>
#include"model.h"
#include"global.h"
#include<time.h>
#include"tool.h"
#include<stdlib.h>
#include"card_file.h"
#include"billing_service.h"
#include"service.h"
ipbillnode head = NULL, current = NULL, prev = NULL;

billing *querybilling(const char* name,int *index)//��ѯ�����ļ���Ϣ
{
	current = head;
	ipbillnode current1 = NULL;
	if (current != NULL)
	{
		current1 = current;
		while (current1 != NULL)
		{
			if (strcmp(current1->date.cardname, name)== 0)
			{
				return &current1->date;
			}
			(*index)++;
			current1 = current1->next;
		}
	}
	return NULL;
}
int addbilltolist(billing bill)//ʵ�������ļ���Ϣ��������
{

	current = (ipbillnode)malloc(sizeof(billnode));
	if (head == NULL)head = current;
	else prev->next = current;
	current->next = NULL;
	current->date = bill;
	prev = current;
	return TRUE;
}
double getamount(time_t start)//�������ѽ��
{
	int sec;
	int min;
	int count;
	double amount;
	time_t end = time(NULL);
	sec = end - start;
	min = sec / 60;
	if (min / 15 == 0)
	{
		count = min / 15;
	}
	else
	{
		count = min / 15 + 1;
	}
	amount = double(count) *2;
	
	return amount;
}
void releasebilllist()//�ͷ��ڴ棬��ֹ�ڴ�й¶
{
	current = head;
	while (current != NULL)
	{
		head = current->next;
		free(current);
		current = head;
	}
	current = NULL;
	head = NULL;
}