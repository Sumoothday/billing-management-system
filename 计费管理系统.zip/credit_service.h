#pragma once
credit* querycredit(const char* name, int* index);
int addcredittolist(credit bill);
void releasecreditlist();
int updatecredit(const credit* pcredit, const char* pPath, int nIndex);