#define _CRT_SECURE_NO_WARNINGS 1
#include"model.h"
#include"global.h"
#include <cstdio>
#include<string.h>
#include"credit_service.h"

void showcredit(credit temp)
{
	char re1[20], re2[20];
	// �������ı�ͷ
	printf("%s\t%d\t\t%s\t\t%d\n", temp.cardname, temp.creditscore, temp.grade, temp.blacklist);
	
}
int readcreditfile()
{
	credit temp;
	FILE* fp = NULL;  // �ļ��ṹ��ָ��

	// ��ֻ���ķ�ʽ���ļ�
	if ((fp = fopen(CREDITPATH, "rb")) == NULL)
	{
		return FALSE;
	}

	while (!feof(fp))
	{
		if (fread(&temp, sizeof(credit), 1, fp) != 0 )
		{
			showcredit(temp);
		}
	}
	fclose(fp);
	return 0;
}
int savecredittofile(const credit* pcredit, const char* path)//��������Ϣ�����ļ�
{
	FILE* fp = NULL;
	if ((fp = fopen(path, "ab")) == NULL)
	{
		return FALSE;
	}
	fwrite(pcredit, sizeof(credit), 1, fp);
	fclose(fp);
}

int readcredit(const char* path)//��ȡ�����ļ��е���Ϣ����������
{
	int count = 0;
	credit temp;
	FILE* fp = NULL;
	if ((fp = fopen(CREDITPATH, "rb+")) == NULL)
	{
		return FALSE;
	}

	while (!feof(fp))
	{
		if (fread(&temp, sizeof(credit), 1, fp) != 0)
		{
			addcredittolist(temp); count++;
		}

	}
	fclose(fp);
	return count;
}
int updatecredit(const credit* pcredit, const char* pPath, int nIndex)//���������ļ���Ϣ
{
	FILE* fp = NULL;    // �ļ�ָ��
	int nLine = 0;      // �ļ�����Ϣ��
	long lPosition = 0; // �ļ�λ�ñ��
	credit bBuf;
	if ((fp = fopen(pPath, "rb+")) == NULL)
	{
		return FALSE;
	}

	while ((!feof(fp)) && (nLine < nIndex - 1))
	{
		if (fread(&bBuf, sizeof(credit), 1, fp) != 0)
		{
			// ��ȡ�ļ���ʶλ��
			lPosition = ftell(fp);
			nLine++;
		}
	}
	// �Ƶ��ļ���ʶλ��
	fseek(fp, lPosition, 0);
	fwrite(pcredit, sizeof(credit), 1, fp);
	fclose(fp);
	return TRUE;
}
int changecreditdate(const char* path)
{
	readcredit(CREDITPATH);
	credit* credit;
	int index=0, ttt;
	int count = 0;
	card temp;
	time_t now = time(NULL);
	FILE* fp = NULL;
	if ((fp = fopen(path, "rb")) == NULL)
	{
		return FALSE; releasecreditlist();
	}
	while (!feof(fp))
	{
		if (fread(&temp, sizeof(card), 1, fp) != 0)
		{
			if (temp.balance < 0)
			{
				credit = querycredit(temp.cardname, &index);
				ttt = (now - credit->settle) / (60);//ÿ��۳�һ������
				credit->settle = time(NULL);
				credit->creditscore -= ttt;
				if (credit->creditscore <= 0)credit->creditscore = 0;
				if (credit->creditscore >= 80 && credit->creditscore < 90)
				{
					strcpy(credit->grade, "B");
				}
				else if (credit->creditscore >= 70 && credit->creditscore < 80)
				{
					strcpy(credit->grade, "C");
				}
				else if (credit->creditscore < 70) {
					strcpy(credit->grade, "D");
				}
				if (strcmp(credit->grade, "D") == 0)
					credit->blacklist = 1;
				updatecredit(credit, CREDITPATH, index + 1);
			}
		}
	}
	releasecreditlist();
	fclose(fp);
	return TRUE;
}

