#pragma 
#include"model.h"
int addcardtofile(card card);
void add();
void refer();
int addbillingtofile(billing bill);
int dologon(const char* name, const char* pwd, logonlnfo* info);
int dosettle(const char* name, const char* pwd, settlelnfo* info);
int doaddmoney(const char* name, const char* pwd, moneylnfo* info);
int dorefundmoney(const char* name, const char* pwd, refundlnfo* info);
int docancel(const char* name, const char* pwd, cancellnfo* info);
