#pragma once
#define KEY "xds812050"
#define CDKEY "KKK"
#define TRUE 1
#define FALSE 0
#define  CARDPATH "data\\card.ams"
#define  BILLINGPATH "data\\billing.ams"
#define CREDITPATH "data\\credit.ams"