#ifndef billing_servie_h
#define billing_service_h
billing *querybilling(const char* name,int *index);
int addbilltolist(billing bill);
double getamount(time_t start);
void releasebilllist();
#endif