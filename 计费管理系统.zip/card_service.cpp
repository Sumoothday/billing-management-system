#define _CRT_SECURE_NO_WARNINGS 1
#pragma once
#include<stdio.h>
#include<string.h>
#include"model.h"
#include"global.h"
#include<time.h>
#include"tool.h"
#include<stdlib.h>
#include"card_file.h"
#include"billing_service.h"
#include"service.h"
card user[100]; int i = 1, j,count=0; 
ipcardnode head = NULL,current=NULL,prev=NULL;

 int addcardtolist(card card)//ʹ�������洢����Ϣ
{
	
	current=(ipcardnode)malloc(sizeof(cardnode));
	if (head ==NULL)head = current;
	else prev->next = current;
	current->next = NULL;
	current->date = card;
	prev = current;
	return TRUE;
}
 void releasecardlist()//�ͷ��ڴ棬��ֹ�ڴ�й¶
 {
	 current = head;
	 while (current != NULL)
	 {
		 head = current->next;
		 free(current);
		 current = head;
	 }
	 current = NULL;
	 head = NULL;
 }


card *refercard( const char* name,int *index)//������������ѯ��Ҫ��card
{
	current = head;
	ipcardnode current1 = NULL;
	card* pcard = (card*)malloc(sizeof(card));
	if (current != NULL)
	{
		current1 = current;
		while (current1 != NULL)
		{
			if (strstr(current1->date.cardname, name)!=NULL)
			{
				pcard[*index] = current1->date;
				(*index)++;
			}			
			pcard = (card*)realloc(pcard, ((*index +1) * sizeof(card)));
			current1 = current1->next;
		}
	}
	return pcard;
}

card *checkcard(const char* name, const char* pwd,int *index)//�����ϡ��»�
{
	current = head;
	ipcardnode current1 = NULL;
	if (current != NULL)
	{		
		current1 = current;
		while (current1 != NULL)
		{		
			if ((strcmp(current1->date.cardname, name) ==0)&&(strcmp(current1->date.pwd,pwd)==0))//�ж��Ƿ�Ϊע����
			{		
				return &current1->date;
			}
			current1 = current1->next;
			(*index)++;
		}
	}
	return NULL;
}
card* showallcard()//չʾ���п�����Ϣ
{
	char re[20], re1[20], re2[20];
	current = head;
	ipcardnode current1 = NULL;
	if (current != NULL)
	{
		current1 = current;
		while (current1 != NULL)
		{
			timetostring(current1->date.lasttime, re);
			timetostring(current1->date.start, re1);
			timetostring(current1->date.end, re2);
			printf("����\t״̬\t���\t�ۼ�ʹ��\tʹ�ô���\t�ϴ�ʹ��ʱ��\t\t����ʱ��\t\t����ʱ��\n");
			printf("%s\t%d\t%0.1f\t%0.1f\t\t%d\t\t%s\t%s\t%s\n", current1->date.cardname, current1->date.status, current1->date.balance, current1->date.totaluse, current1->date.usecount, re, re1, re2);
			
			current1 = current1->next;
		}
	}
	return NULL;
}
card* countdate(float* totaluse, float* earn)//��������Ӫҵ��
{
	*totaluse = 0, * earn = 0;
	char re[20], re1[20], re2[20];
	current = head;
	ipcardnode current1 = NULL;
	if (current != NULL)
	{
		current1 = current;
		while (current1 != NULL)
		{
			*totaluse += current1->date.totaluse;
			*earn += current1->date.totaluse - current1->date.balance;
			current1 = current1->next;
		}
	}
	return NULL;




}