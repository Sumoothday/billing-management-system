#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<stdlib.h>
#include"menu.h"
#include"card_service.h"
#include"model.h"
#include"billing_service.h"
#include"global.h"
#include"service.h"
#include"billing_file.h"
#include"credit_file.h"
#include"credit_service.h"
#include"card_file.h"
char order; 
int t = 1;
int main()
{
	changecreditdate(CARDPATH);
	system("color 9");
	print();
    outputmenu();
while (t)
{
	scanf("%c", &order);
	if (order== '\n')
	continue;
	getchar();
	switch (order- '0')
	{
	outputmenu();
	case 1:system("cls");  add();       outputmenu(); break;
	case 2:system("cls"); refer();	   releasecardlist();   outputmenu(); break;
	case 3:system("cls"); logon();		releasecardlist(); releasebilllist(); outputmenu(); break;
	case 4:system("cls"); settle();	    releasecardlist(); releasebilllist(); releasecreditlist; outputmenu(); break;
	case 5:system("cls"); addmoney();	releasecardlist();	releasebilllist(); outputmenu(); break;
	case 6:system("cls");refundmoney(); releasecardlist();	releasebilllist(); outputmenu(); break;
	case 7:system("cls"); count();	    releasecardlist();	releasebilllist(); outputmenu(); break;
	case 8:system("cls"); cancel();     releasecardlist();	releasebilllist();  outputmenu(); break;
	case 9:system("cls"); docredit();   outputmenu(); releasecreditlist; break;
	case 0:t = 0;					    releasecardlist();          break;
	default:printf("����������������룺\n");
	}

}
printf("�˳��ɹ�!");
}
