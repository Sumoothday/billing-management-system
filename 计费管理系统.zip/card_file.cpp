#pragma once
#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<string.h>
#include"model.h"
#include"global.h"
#include<time.h>
#include"tool.h"
#include<stdlib.h>
#include"card_service.h"
#include"credit_file.h"
#include"credit_service.h"
int savecard(const card* pcard, const char* path)//������Ϣ�����ļ�
{
	FILE* fp = NULL;
	if ((fp = fopen(path, "ab")) == NULL)
	{
		return FALSE;
	}
	fwrite(pcard, sizeof(card), 1, fp);
	fclose(fp);


}

int readcard(const char* path)//��ȡ�ļ��п���Ϣ����������
{
	int count = 0;
	card temp;
	FILE* fp = NULL;
	if ((fp = fopen(CARDPATH, "rb")) == NULL)
	{
		return FALSE;
	}

	while (!feof(fp))
	{
		if (fread(&temp, sizeof(card), 1, fp) != 0)
		{
			addcardtolist(temp);count++;
		}
		
	}
	fclose(fp);
	return count;
}



int updatecard(const card* pcard, const char* pPath, int nIndex)//�����ļ��еĿ���Ϣ
{
	FILE* fp = NULL;    // �ļ�ָ��
	int nLine = 0;      // �ļ�����Ϣ��
	long lPosition = 0; // �ļ�λ�ñ��
	card bBuf;
	if ((fp = fopen(pPath, "rb+")) == NULL)
	{
		return FALSE;
	}

	while ((!feof(fp)) && (nLine < nIndex - 1))
	{
		if (fread(&bBuf, sizeof(card), 1, fp) != 0)
		{
			// ��ȡ�ļ���ʶλ��
			lPosition = ftell(fp);
			nLine++;
		}
	}
	// �Ƶ��ļ���ʶλ��
	fseek(fp, lPosition, 0);
	fwrite(pcard, sizeof(card), 1, fp);
	fclose(fp);
	return TRUE;
}
int isExsit(char* num, const char* path)//��鿨��Ϣ�Ƿ��Ѵ��ڵĿ�
{
	int count = 0;
	card temp;
	FILE* fp = NULL;
	if ((fp = fopen(CARDPATH, "rb")) == NULL)
	{
		return FALSE;
	}

	while (!feof(fp))
	{
		if (fread(&temp, sizeof(card), 1, fp) != 0)
		{
			if (strcmp(temp.cardname, num) == 0)
				return TRUE;
		}
		count++;
	}
	fclose(fp);
	return FALSE;
	
}





