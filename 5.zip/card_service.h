#ifndef card_service_h
#define card_service_h
#include"model.h"
void add();
void refer();
void cancel();
void releasecardlist();
int addcardtolist(card card);
card* dologon(const char* name, const char* pwd);
int updatecard( const card* pcard, const char* path, int index);
#endif