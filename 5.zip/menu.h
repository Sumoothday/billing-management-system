#ifndef menu_h
#define menu_h
void print();
void outputmenu();
void logon();
#endif
 