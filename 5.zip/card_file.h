#pragma once
#include"model.h"
int savecard(const card* pcard, const char* path);
card prasecard(char* puff);
int readcard(const char* path);
int isExsit(char* num, const char* path);
