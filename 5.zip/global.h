#pragma once
#define TRUE 1
#define FALSE 0
#define  CARDPATH "data\\card.txt"
#define  CARDPATH2 "data\\card2.txt"