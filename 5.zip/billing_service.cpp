#include<stdio.h>
void recharge()
{
	printf("��ֵ\n");
}
void refund()
{
	printf("�˷�\n");
}