#include<stdio.h>
//#include"date.h"
void inquiry()
{
	printf("��ѯͳ��\n");
}
