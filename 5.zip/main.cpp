#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<stdlib.h>
#include"menu.h"
#include"card_service.h"
#include"rate_service.h"
#include"model.h"
#include"billing_service.h"
#include"record_service.h"
#include"global.h"
char order; int t = 1;
int main()
{
	system("color 9");
	print();
    outputmenu();
while (t)
{
	scanf("%c", &order);
	if (order== '\n')continue;getchar();
	switch (order- '0')
	{
		outputmenu();
	case 1:system("cls");  add();       outputmenu(); break;
	case 2:system("cls"); refer();	    outputmenu(); break;
	case 3:system("cls"); logon();	    outputmenu(); break;
	case 4:system("cls"); settlelnfo(); outputmenu(); break;
	case 5:system("cls"); recharge();   outputmenu(); break;
	case 6:system("cls"); refund();     outputmenu(); break;
	case 7:system("cls"); inquiry();    outputmenu(); break;
	case 8:system("cls"); cancel();     outputmenu(); break;
	case 0:t = 0;         releasecardlist();          break;
	default:printf("����������������룺\n");
	}

}

printf("�˳�");
releasecardlist();



}
