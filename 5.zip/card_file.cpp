#pragma once
#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<string.h>
#include"model.h"
#include"global.h"
#include<time.h>
#include"tool.h"
#include<stdlib.h>
#include"card_service.h"

int savecard(const card* pcard, const char* path)//������Ϣ�����ļ��ĺ���
{
	FILE* fp = NULL;
	char starttime[20] = { 0 };
	char endtime[20] = { 0 };
	char lasttime[20] = { 0 };
	if ((fp = fopen(path, "a")) == NULL)
	{
		fp = fopen(path, "r+");
		if (fp == NULL)
		{
			fclose(fp);return FALSE;
		}

	}
	timetostring(pcard->start, starttime);
	timetostring(pcard->end, endtime);
	timetostring(pcard->lasttime, lasttime);
	fprintf(fp, "%s##%s##%d##%0.1f##%0.1f##%d##%s##%s##%s\n", pcard->cardname,pcard->pwd, pcard->status, pcard->balance, pcard->totaluse, pcard->usecount, starttime, endtime, lasttime);
	fclose(fp);
	return TRUE;
}

card prasecard(char* puff)//��ÿ�ſ���Ϣ������Ϊcard���͵ĺ���
{
	card card = { 0 };
	int i = 0;
	const char* delims = "##";
	char* buf = NULL;
	char* str = NULL;
	char flag[10][20] = { 0 };
	buf = puff;
	while ((str = strtok(buf, delims)) != NULL)
	{
		strcpy(flag[i], str);
		buf = NULL;
		i++;
	}
	strcpy(card.cardname, flag[0]);
	strcpy(card.pwd, flag[1]);
	card.status=atoi(flag[2]);
    card.balance = (float)atof(flag[3]);
    card.totaluse = (float)atof(flag[4]);
    card.usecount = atoi(flag[5]);
	card.start = stringtotime(flag[6]);
	card.end = stringtotime(flag[7]);
	card.lasttime = stringtotime(flag[8]);
	return card;
}
int readcard(const char* path)//���ļ��ж�ȡ����Ϣ���������ĺ���,�����㿨����
{
	int count = 0;
	FILE* fp = NULL;
	char puff1[200] = { 0 };
	fp = fopen(path, "r");
	if (fp  == NULL)
	{
		fclose(fp);
		return FALSE;
	}
	while (feof(fp)==0)
	{
		
		memset(puff1, 0, 200);
		while (fgets(puff1, 200, fp) != NULL)
		{
			count++;
			if (strlen(puff1) > 0)
			{
				
				addcardtolist(prasecard(puff1));//��������
			}
			
		}
	}
	fclose(fp);
	return count;

}
int isExsit(char* num, const char* path)//��鿨��Ϣ�Ƿ��Ѵ��ڵĿ�
{

	FILE* fp = NULL;
	char puff1[200] = { 0 };
	fp = fopen(path, "r");
	if (fp == NULL)
	{
		fclose(fp);
		return TRUE;
	}
	while (feof(fp) == 0)
	{

		memset(puff1, 0, 200);
		while (fgets(puff1, 200, fp) != NULL)
		{
			if (strcmp(prasecard(puff1).cardname, num) == 0)
			{
				fclose(fp);
				return TRUE;

			}
			memset(puff1, 0, 200);

		}
	}
	fclose(fp);
	return FALSE;
}




