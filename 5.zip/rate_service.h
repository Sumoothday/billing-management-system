#ifndef rate_service_h
#define rate_service_h
void inquiry();
#endif